package story;

public class WeatherException extends Exception{
    WeatherException(String message){
        super(message);
    }
    WeatherException(){
    }
}
