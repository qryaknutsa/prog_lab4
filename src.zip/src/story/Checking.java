package story;

public interface Checking {
    int checking(Creature obj);
}
