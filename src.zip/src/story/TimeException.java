package story;

public class TimeException extends RuntimeException {
    TimeException(String message) {
        super(message);
    }
    TimeException() {
    }

}
