package story;

public class IncrorrectValueException extends RuntimeException {
    IncrorrectValueException(String message) {
        super(message);
    }

    IncrorrectValueException() {
    }

}

