package story;

//n - расстояниие, больше которого объект перепрыгнуть не сможет
interface WayOfMoving {
    void move(Creature c, int i);
}
