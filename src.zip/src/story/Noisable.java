package story;

public interface Noisable {
    String makeNoise(Buildings.Windows window, Noise noise, Integer t);
}
